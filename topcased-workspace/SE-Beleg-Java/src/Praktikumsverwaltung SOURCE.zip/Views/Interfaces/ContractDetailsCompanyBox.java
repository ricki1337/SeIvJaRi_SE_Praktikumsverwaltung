package Views.Interfaces;

/**
 * Muss von einer Box implementiert werden,<br>
 * um in der Contract-View auf dem Platzhalter der Firmenansicht angezeigt zu werden.
 */
public interface ContractDetailsCompanyBox extends EditBox{}
