package Views.Interfaces;
/**
 * Muss von einer Box implementiert werden,<br>
 * um in der Contract-View auf dem Platzhalter der Betreueransicht angezeigt zu werden.
 */
public interface ContractDetailsProfBox extends EditBox{}
