package Views.Interfaces;
/**
 * Muss von einer Box implementiert werden,<br>
 * um in der Contract-View auf dem Platzhalter der Studentenansicht angezeigt zu werden.
 */
public interface ContractDetailsStudentBox extends EditBox {}
